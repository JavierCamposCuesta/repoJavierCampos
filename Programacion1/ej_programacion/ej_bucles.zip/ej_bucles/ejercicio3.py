''' 3.Diseñar un programa que muestre los 10 primeros números que son múltiplos 
de 3 (hay que hacerlo pensando que no sabemos cuáles son los números múltiplos 
de 3.)'''

for i in range(3, 3*10+1,3):
    print(i)
