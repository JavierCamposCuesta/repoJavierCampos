package Examen5Marzo;

public class MainStringUtil {

	public static void main(String[] args) {
	StringUtil prueba1= new StringUtil();
	System.out.println(prueba1.compruebaSubcadena("hola", "ho"));

	}

}
