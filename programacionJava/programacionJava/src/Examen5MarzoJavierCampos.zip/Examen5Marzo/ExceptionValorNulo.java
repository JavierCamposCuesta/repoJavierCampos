package Examen5Marzo;

public class ExceptionValorNulo extends Exception{
	public ExceptionValorNulo() {
		super("La contraseña no puede ser nula");
	}

}
