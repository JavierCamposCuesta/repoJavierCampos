package Ciudades;

import java.io.File;

public class Main {

	public static void main(String[] args) {
		
		ListaPaises l;
		try {
			l = new ListaPaises("./Ficheros/country.txt, ./Ficheros/city.txt, ./Ficheros/address2.txt");
			System.out.println(l);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("dsfdfd");
		}
		
		
		
		
//		ListaPaises paises = new ListaPaises();
//		try {
//			File f = new File("./Ficheros/country.txt");
//			String list[] = f.list();
//			
//			paises.cargarDatos("./Ficheros/country.txt");
//			System.out.println("./Ficheros/country.txt");
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			System.out.println(e.getMessage());
//		}
		
		

	}

}
