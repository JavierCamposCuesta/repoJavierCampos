package Ciudades;

import java.util.HashSet;

public class Ciudad {
	private int idCiudad;
	private String nombreCiudad;
	public HashSet<Direccion> listaDirecciones;
	
	public Ciudad(int idCiudad, String nombreCiudad) {
		super();
		this.idCiudad=idCiudad;
		this.nombreCiudad=nombreCiudad;
		this.listaDirecciones = new HashSet<Direccion>();
	}

	public int getIdCiudad() {
		return idCiudad;
	}

	public void setIdCiudad(int idCiudad) {
		this.idCiudad = idCiudad;
	}

	public String getNombreCiudad() {
		return nombreCiudad;
	}

	public void setNombreCiudad(String nombreCiudad) {
		this.nombreCiudad = nombreCiudad;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idCiudad;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ciudad other = (Ciudad) obj;
		if (idCiudad != other.idCiudad)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb= new StringBuilder();
		sb.append("Ciudad [idCiudad=" + idCiudad + ", nombreCiudad=" + nombreCiudad +"\n" );
		for(Direccion direccion : listaDirecciones) {
			sb.append("\t" + direccion.toString() + "\n");
		}
				
		
		
		return sb.toString();
	}
	
	public boolean addDireccion(Direccion d) {
		return listaDirecciones.add(d);
	}
	
	

}
