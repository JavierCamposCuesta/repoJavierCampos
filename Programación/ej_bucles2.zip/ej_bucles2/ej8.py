'''8.Design a program that asks for a set of numbers. After inputting each number, theprogram should ask 
“Do you want to enter more numbers (Y/N)?”. If the answer is “Y”the program asks for other numbers. 
When the user finishes to enter all the numbers,the program should say which one is the smallest. 
The messages are the following:“Enter one number:”“Do you want to enter more number (Y/N)?”“
The smallest number is XX'''

n= int(input("Ingrese un número: "))
pregunta="y"

while pregunta.lower()== str("y"):
    n1=int(input("Ingresa otro numero: "))
    pregunta = input("Quiere introducir otro numero (Y/N)")
    if n<n1:
        if pregunta.lower()==str("n"):
            print(str(n) + " es el menor")
    elif n1<n:
        n=n1
        if pregunta.lower()==str("n"):
            print(str(n) + " es el menor")
    else:
        if pregunta.lower()==str("n"):
            print("Los numeros son iguales")
                    
    
    




